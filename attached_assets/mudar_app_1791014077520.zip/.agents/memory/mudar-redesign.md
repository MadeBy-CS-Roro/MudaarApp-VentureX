---
name: Mudar redesign
description: App renamed to مُدار (Mudar); dark ring design; login; pay-all via open banking style.
---
- User-facing name is "مُدار" (Mudar). Keep technical names (mawid.db, MAWID_* env vars, mawid_token key, module names).
- static/app.js + app.css are a full rewrite matching the team's dark "ring" home design. Keep the look:
  dark default, teal ring, raised purple home button in the middle of the bottom bar, chat bubble on the left, heart (wishlist) top left.
- Login is passwordless: /api/auth/signup|login|verify (phone + 6-digit code; demo returns demo_code), /api/auth/demo quick login as Noura.
  Requests without a token are rejected unless MUDAR_ALLOW_ANON=1 (tests only, set in tests/conftest.py).
- /api/consent connects the bank for the LOGGED-IN user.
- "ادفع الكل" = /api/payments/due + /api/payments/pay (demo-only, simulated open banking payment initiation; 501 in production).
  This is different from /api/plans/{id}/pay-all (early full settlement of one plan).
- Categories are a fixed list in detect.CATEGORIES; validate against detect.ALL_CATEGORIES.
- v4: several banks per user (/api/banks GET/POST/DELETE; transactions.bank_id; expenses show bank_name).
  demo1 = salary account (pitch numbers), demo2 = credit card with Netflix/Shahid/Spotify subscriptions, demo3 = small account.
- Subscriptions are plans with kind "subscription": renewal reminder alert 3 days before (remind flag),
  "ناوي ألغيه" (cancel_planned), POST /api/plans/{id}/cancelled moves it to previous payments.
- Planner: offers.py = installments (sample price caps) + loans.py (sample lenders, real maths: flat rate, 1% fee capped 5,000,
  APR, debt-burden 33.33%). Loans hidden under 5,000 SAR. One recommendation + "قارن كل الخيارات".
- Opening animation (splash) + draggable orbit logo on the welcome screen. Icons generated from the team logo.
- English: static/i18n.js translates the Arabic UI and API messages at runtime (exact phrases, sentence patterns,
  word fallback). Language switch is in حسابي ("اللغة · Language"); stored in localStorage "mudar_lang"; English is LTR.
  Chat sends `lang`; the assistant answers in English (LLM instruction + English rule-based fallback).
  When adding new Arabic text, add its English to i18n.js (P for fixed text, R for sentences with numbers/names).
- Plan limits count COMMITMENTS only (plans with payments left: installments, loans, rent, subscriptions, manual);
  bills are living costs and never count. Users can add up to the limit exactly. Same rule in the assistant.
- Assistant respects the plan: planner/compare tools need Plus, forecast needs Premium, questions per month 5/30/unlimited.
- Quick demo login creates a private guest copy per visitor (users.is_demo_guest); guests older than 24h are cleaned up.
- Account: PATCH /api/account (name, email); phone change by code: POST /api/account/phone and /api/account/phone/verify.
- Money-management score (score.py): 0-100 from 6 parts, all ratios against the user's own salary/targets (fair across
  incomes; a test checks 4x amounts give the same score). Points = score + bonus events (score_events, unique ref).
  Standings: /api/leaderboard ranks score only, nicknames only, opt-in (users.leaderboard_opt_in). Demo rivals are sample.
  It's the FIRST slide on home; trophy icon opens #standings.
- Provider links: service.PROVIDER_SITES (official sites only); obligations return `site` per item and `payees`.
- Planner handles any big expense: wishlist.kind item|trip|event|education|other. Offer ranking = cheapest you can
  start within a month (avoid recommending long expensive loans just to start now).
