---
name: Mudar redesign
description: App renamed to مُدار (Mudar); dark ring design; login; pay-all via open banking style.
---
- User-facing name is "مُدار" (Mudar). Keep technical names (mawid.db, MAWID_* env vars, mawid_token key, module names).
- static/app.js + app.css are a full rewrite matching the team's dark "ring" home design. Keep the look:
  dark default, teal ring, raised purple home button in the middle of the bottom bar, chat bubble on the left, heart (wishlist) top left.
- Login is passwordless: /api/auth/signup|login|verify (phone + 6-digit code; demo returns demo_code), /api/auth/demo quick login as Noura.
  Requests without a token are rejected unless MUDAR_ALLOW_ANON=1 (tests only, set in tests/conftest.py).
- /api/consent connects the bank for the LOGGED-IN user.
- "ادفع الكل" = /api/payments/due + /api/payments/pay (demo-only, simulated open banking payment initiation; 501 in production).
  This is different from /api/plans/{id}/pay-all (early full settlement of one plan).
- Categories are a fixed list in detect.CATEGORIES; validate against detect.ALL_CATEGORIES.
